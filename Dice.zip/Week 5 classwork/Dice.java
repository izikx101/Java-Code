public class Dice
{
    public static void main(String[] args){
        int first, second;
        int counter = 0;
        boolean isDoubles = false;
        while (!isDoubles)
        {
            first = (int)(Math.random()*(6-1+1)-1);
            second = (int)(Math.random()*(6-1+1)-1);
            
            System.out.println(first + "\t" + second + "\t");
            isDoubles = first == second || second == first;  
            counter++;
        }
        System.out.println("Double! It took " + counter + " tries to get it!");
        }
    }
