
/**
 * @author (Isaac Rivera)
 */
public class Human
{
    // instance variables 
    private String eyeColor; 
    private String skinTone;
    private boolean oldYoung;  //If say person is old or young
    private int arm;  //how many arms say person has
    private String name;
    
    private Adult college, knowledge, anxiety;
    private Children school, stressfree, parents;
    
    private String College; //adult
    private String Knowledge;
    private String Anxiety;
    
    private String School; //children
    private String Stressfree;
    private String Parents;
    
    public Human(Adult college, Children school)
    {
        //Adult
        this.college = college;
        this.knowledge = new Adult();
        this.anxiety = new Adult();
        //Children
        this.school = school;
        this.stressfree = new Children();
        this.parents = new Children();
    }
    public Human(String e, String s, boolean o, int a, String n)
    {
        // initialise instance variables
        eyeColor = e;
        skinTone = s;
        oldYoung = o;
        arm = a;
        name = n;
    }
    //Accessor (getter)
    public String getName(){
        return name;
    }
    public String getSkinTone(){
        return skinTone;
    }
    public boolean getOldYoung(){
        return oldYoung;
    }
    public int getArm(){
        return arm;
    }
    //Mutators (setter)
    public void setArm(int a){
        arm = a;
    }
    public void setName(String n){
        name = n;
    }
    public void oldYoung(boolean o){
        boolean oldYoung = o;
        
        if (oldYoung == true){
            System.out.println("young");
        }
        else{
            System.out.println("old");
        }
    }
    public void setEyeColor(String e){
        eyeColor = e;
    }
    public void setSkinTone(String s){
        skinTone = s;
    }
}