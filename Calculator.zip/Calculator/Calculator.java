
/**
 * Write a description of class Calculator here.
 *
 * @author (Isaac Rivera)
 * @version (a version number or a date)
 */
public class Calculator
{
    // instance variables - replace the example below with your own
    public static void main (double a, double b)

    /**
     * Constructor for objects of class Calculator
     */
    
    {
        // initialise instance variables
        double s=a+b;
        double c=a-b;
        double m=a*b;
        double d=a/b;
    

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    
    
        // put your code here
System.out.println("The sum of the given numbers is "+s);
System.out.println("The difference between the given numbers is "+c);
System.out.println("The product of the given numbers is "+m);
System.out.println("The division of the given numbers is "+d);
    }
}
