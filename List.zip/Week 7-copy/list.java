import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
public class list
{
    public static void main(String[] args){
        int [] list = new int[100];
        ArrayList<Integer> list2 = new ArrayList<Integer>();
        Scanner keybd = new Scanner(System.in);
        Iterator<Integer> itr;
        Random rand = new Random();
        
        
        for(int i = 0; i < 100; i++)
        {
            list[i] = rand.nextInt();
        }
        
        for(int i = 0; i < 100; i++)
        {
            System.out.println(list[i]%50 == 0 ? list[i] + ": >=50" : list[i] + ": <50");
        }
        }
    }