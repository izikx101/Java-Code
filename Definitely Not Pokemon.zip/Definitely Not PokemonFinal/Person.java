import java.util.*;
/**
 * Write a description of class person here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Person
{
    // instance variables - replace the example below with your own
    private final String name;
    private final int age;
    private ArrayList<Creature> team = new ArrayList<Creature>();
    private HashMap<Integer, String> dex = new HashMap<Integer, String>();
    private Random rand = new Random();
    Scanner keybd = new Scanner(System.in);
    
    /**
     * Constructor for objects of class person
     */
    public Person(String name, int age)
    {
        // initialise instance variables
        this.name = name;
        this.age = age;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getAge(){
        return this.age;
    }
    
    //adds the creature to the current team
    public void caught(Creature c){
        this.team.add(c);
        addToDex(c);
    }
    
    //prints out the current catcher's team
    public void printTeam(){
        for(Creature c : team){
            System.out.println(c.getName());
            c.displayStats();
            c.displayType();
        }
    }
    
    //Adds to HashMap of creatures 
    public void addToDex(Creature c){
        dex.put(c.getDexNum(), c.getName());
    }
    
    //Prints out the dex entries
    public void getDex(){
        System.out.println("Your current dex looks like this:");
        System.out.println(dex);
    }
    
    public void battle(){
        System.out.println("You have run into a creature, what would you like to do?");
        System.out.println("Type one of the following numbers\n1: Catch\n2: Run Away");
        int answer = keybd.nextInt();
        if(answer == 1){
            System.out.println("You have decided to catch the creature!");
            System.out.print("You have caught a ");
            switch(rand.nextInt(4)){
                case 0:
                    System.out.println("badger!");
                    caught(new Creature("badger"));
                    for(Creature c : team){
                        c.displayStats();
                        c.displayType();
                    }
                    break;
                case 1:
                    System.out.println("ocelot!");
                    caught(new Creature("ocelot"));
                    for(Creature c : team){
                        c.displayStats();
                        c.displayType();
                    }
                    break;
                case 2:
                    System.out.println("werewolf!");
                    caught(new Creature("werewolf"));
                    for(Creature c : team){
                        c.displayStats();
                        c.displayType();
                    }
                    break;
                case 3:
                    System.out.println("cat!");
                    caught(new Creature("cat"));
                    for(Creature c : team){
                        c.displayStats();
                        c.displayTipe();
                    }
                    break;
                default:
                    System.out.println("");
            }
        }
        else if(answer == 2){
            System.out.println("You have successfully run away!");
        }
        else{
            System.out.println("You babble in some unknown command and the creature leaves out of confusion");
        }
    }
}
