import java.util.Random;
import java.util.Scanner;
import java.util.*;
/**
 * Write a description of class creature here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Creature
{
    // instance variables - replace the example below with your own
    private final String name;
    private int dexNum; //specific number 
    private String nickname; //Allows for a private name
    private ArrayList<Creature> team = new ArrayList<Creature>();
    private String coolname;

    //Stats
    private int atk, def, spd, hp;
    
    //initialize other class objects
    private final Scanner keybd = new Scanner(System.in);
    private final Random rand = new Random();
    
    /**
     * Constructor for objects of class creature
     */
    public Creature(String name)
    {
        // initialise instance variables
        this.name = name;
        logging(name);
        
        //Randomly set stats
        this.atk = rand.nextInt(10);
        this.def = rand.nextInt(10);
        this.spd = rand.nextInt(10);
        this.hp = 10+rand.nextInt(10);
        
        //
    }
    
    public void coolname(){
        //Nickname your creature
        System.out.println("Do you want to nickname your creature? (y/n)\n");
        if(keybd.nextLine().toLowerCase().equals("y")){
            System.out.println("What would you like to nickname your creature?");
            setCoolname(keybd.nextLine());
        }
        else{
            setCoolname(name);
        }
    }
    
    //getters and setters
    public void setCoolname(String coolname){
        this.coolname = coolname;
    }
    
    public String getCoolname(){
        return this.coolname;
    }
    
    public int getDexNum(){
        return this.dexNum;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getAtk(){
        return this.atk;
    }
    
    public int getDef(){
        return this.def;
    }
    
    public int getSpd(){
        return this.spd;
    }
    
    public int getHP(){
        return this.hp;
    }

    public void levelUp(){
        this.atk += rand.nextInt(3);
        this.def += rand.nextInt(3);
        this.spd += rand.nextInt(3);
        this.hp += rand.nextInt(3);
    }
    
    public void displayStats(){
        System.out.println("HP: " + hp);
        System.out.println("Attack: " + atk);
        System.out.println("Defence: " + def);
        System.out.println("Speed: " + spd);
    }
    
    public void displayTipe(){ //breed types
        switch(name.toLowerCase()){
            case "badlot":
                System.out.println("Fire" + "\n");
                break;
            case "cat-ger":
                System.out.println("Water" + "\n");
                break;
            case "were-at":
                System.out.println("Grass" + "\n");
                break;
            case "badwolf":
                System.out.println("Earth" + "\n");
                break;
            default:
                System.out.println("");
        }
    }
    
    public void displayType(){ //types
        switch(name.toLowerCase()){
            case "badger":
                System.out.println("Fire" + "\n");
                break;
            case "ocelot":
                System.out.println("Water" + "\n");
                break;
            case "werewolf":
                System.out.println("Grass" + "\n");
                break;
            case "cat":
                System.out.println("Earth" + "\n");
                break;
            default:
                System.out.println("");
        }
    }
    
    public void logging(String name){
        switch(name.toLowerCase()){
            case "badger":
                this.dexNum = 0;
                break;
            case "ocelot":
                this.dexNum = 1;
                break;
            case "werewolf":
                this.dexNum = 2;
                break;
            case "cat":
                this.dexNum = 3;
                break;
            case "badlot":
                this.dexNum = 4;
                break;
            case "cat-ger":
                this.dexNum = 5;
                break;
            case "were-at":
                this.dexNum = 6;
                break;
            case "badwolf":
                this.dexNum = 7;
                break;
            default:
                this.dexNum = -1;
        }
    }
    
    public void breed(){
        System.out.println("Would you like to breed the creatures?");
        System.out.println("Type one of the following numbers \n1: Baby\n2: No");
        int answer = keybd.nextInt();
        if(answer == 1){
            System.out.println("Time to make a baby!");
            System.out.print("You have a ");
            switch(rand.nextInt(4)){
                case 0:
                    System.out.println("badlot!");
                    caught(new Creature("badlot"));
                    for(Creature c : team){
                        c.displayStats();
                        c.levelUp();
                        c.displayTipe();
                    }
                    break;
                case 1:
                    System.out.println("cat-ger!");
                    caught(new Creature("cat-ger"));
                    for(Creature c : team){
                        c.displayStats();
                        c.levelUp();
                        c.displayTipe();
                    }
                    break;
                case 2:
                    System.out.println("were-at!");
                    caught(new Creature("were-at"));
                    for(Creature c : team){
                        c.displayStats();
                        c.levelUp();
                        c.displayTipe();
                    }
                    break;
                case 3:
                    System.out.println("badwolf!");
                    caught(new Creature("badwolf"));
                    for(Creature c : team){
                        c.displayStats();
                        c.levelUp();
                        c.displayTipe();
                    }
                    break;
            }
        }
        else if(answer == 2){
            System.out.println("Ok keep on catching!");
        }
        else{
            System.out.println("You didn't understand so you went on");
        }
    }
    
    public void caught(Creature c){
        this.team.add(c);
    }
}