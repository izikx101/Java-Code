import java.util.*;
/**
 * Write a description of class main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class main
{
    public static void main(String[] args){
        Scanner keybd = new Scanner(System.in);
        boolean running = true; //true as long as you want to play
        String choice = "";
        
        System.out.println("Welcome to the world of definitely not pokemon!");
        System.out.println("This game will allow you to catch creatures, level them up, and let you build your collection!");
        System.out.println("Let's start with you typing your name!");
        String n = keybd.nextLine();
        System.out.println("Next, how old are you?");
        int a = keybd.nextInt();
        keybd.nextLine();
        Person catcher = new Person(n, a);
        Creature baby = new Creature(n);
        while(running){
            System.out.println("What would you like to do, " + catcher.getName() + "?" );
            options();
            switch(keybd.nextLine().toLowerCase()){
                case "catch":
                    catcher.battle();
                    break;
                case "team":
                    catcher.printTeam();
                    break;
                case "dex":
                    catcher.getDex();
                    break;
                case "breed":
                    baby.breed();
                    break;
                case "goodbye":
                    System.out.println("Thanks for playing!");
                    running = false;
                    break;
                default:
                    System.out.println("Sorry, but that's not a valid choice... \n");
            }
        }
    }
    
    public static void options(){
        System.out.println("Catch: Catches a new creature");
        System.out.println("Team: Looks at your current team");
        System.out.println("Dex: Views the creatures you have caught and logged");
        System.out.println("Breed: breed two creatures to make a strong baby");
        System.out.println("Goodbye: ends the game");
    }
}
