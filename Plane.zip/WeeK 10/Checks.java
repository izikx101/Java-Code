import java.util.Scanner;
import java.util.Random;
public class Checks
{
    private int plane;
    public static void main(String[] args)
    {
        Scanner keybd = new Scanner(System.in);
        Ticket t = new Ticket();
        while(true){
            System.out.println("Please enter in your ticket (1)");
            int choice = keybd.nextInt();
            switch(choice)
            {
                case 1:
                    t.flightNum();
                    t.seatNum();
                    t.flightTime();
                case 2:
                    System.out.println("Invalid flight");
    
            }
        }
        
    }
    
    public void plane()
    {
        //have plane set to 90 seats only to be filled
        Random rand = new Random();
        plane = rand.nextInt(90);
        if (plane > 90)
        {
            System.out.println("sorry plane is full");
        }
        else if (plane < 90)
        {
            System.out.println("welcome aboard!");
        }
    }
}