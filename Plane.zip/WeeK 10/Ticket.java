import java.util.Scanner;
import java.util.Random;
public class Ticket
{
    private String classes;
    private int flight;
    private int seat;
    private int time;
    private Random rand = new Random();
    private Scanner keybd = new Scanner(System.in);
    public Ticket()
    {
        switch(rand.nextInt(3)+1)
        {
            case 1:
                classes = "First Class";
            case 2:
                classes = "Business Class";
            case 3:
                classes = "Economy Class";
        }
    }
    
    public void flightNum()
    {
        System.out.println("your flight is " + flight);
        flight = rand.nextInt(99)+1;
    }
    
    public void seatNum()
    {
        System.out.println("your seat number is " + seat);
        seat = rand.nextInt(90);
    }
    
    public void flightTime()
    {
        System.out.println("your flight time is " + time);
        time = 300;
    }    
}
