import java.util.Scanner;
import java.util.List;
import java.util.Date;
/**
 */
public class main2
{
    public static void main(String[] args){
        Scanner keybd = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        boolean mainLoop = true;
        
        System.out.println("Welcome to the Theater! Enter '0' to accses the Menu.");
        String name = keybd.nextLine();
        
        Theater now = new Theater(name);
        
        int choice;
        do{
            System.out.println(" Theater Menu ");
            System.out.println("1.) Update the movie list ");
            System.out.println("2.) Current Movies in Theather ");
            System.out.println("3.) Run all Movies ");
            System.out.println("4.) Exit ");
            System.out.println(" Enter Menu Choice ");
            
            choice = input.nextInt();
        }
        
        while(choice >5);
        
        switch(choice){
            case 1 : 
                
                break;
            
            case 2 :
                
                break;
                
            case 3 :
                
                break;
                
            case 4 :
                System.out.println("Goodbye!");
                System.exit(0);
                break;
            default :
                System.out.println("That is not a valid Menu Option");
                 break;
        }
    }
}
