import java.util.ArrayList;
import java.util.HashMap;
/**
 */
public class Theater
{
    // variables
    private String name;
    private ArrayList<Movie> list;
    private HashMap<String, Integer> room;

    /**
     * Constructor for objects of class Theater
     */
    public Theater(String name)
    {
        // initialise instance variables
        this.name = name;
        list = new ArrayList<Movie>();
        room = new HashMap<String, Integer>();
    }
    // getter
    public String getName(){
        return name;
    }
    // method for updating the rooms with different movies from the list
    public void update(Movie d){
        list.add(d);
    }
    // prints out the current selection that is out right now
    public void screenings(){
        for(Movie d : list){
            d.showTitles();
            System.out.println();
        }
    }
    // all movies to print out
    public void allMovies(Movie d){
        System.out.println(list);
    }
}