import java.util.Random;
/**
 */
public class Movie
{
    // variables
    private String title;
    private int runtime;
    private int movieNum;
    private Random rand = new Random();
    /**
     * Constructor for objects of class Movie
     */
    public Movie()
    {
        // giving the moives some base values 
        this.title = title;
        switch(title){
            case " The Exorcist " :
                movieNum = 1;
                break;
            case " Halloween " :
                movieNum = 2;
                break;
            case " A Nightmare on Elm Street " :
                movieNum = 3;
                break;
            case " Night of the Living Dead " :
                movieNum = 4;
                break;
            case " Suspiria " :
                movieNum = 5;
                break;
            case " The Texas Chainsaw Massacre " :
                movieNum = 6;
                break;
            case " Saw " :
                movieNum = 7;
                break;
            case " Scream " :
                movieNum = 8;
                break;
            case " Freaks " :
                movieNum = 9;
                break;
            case " Psycho " :
                movieNum = 10;
                break;
            default:
                movieNum = 0;
        }
        
        // random runtime for each of the movies
        this.runtime = 90 + rand.nextInt(120);
    }
    // getter
    public String getTitle(){
        return title;
    }
    // getter
    public int getRunTime(){
        return runtime;
    }
    // getter
    public int getMovieNum(){
        return movieNum;
    }
    // helps out with theater screenings
    public void showTitles(){
        System.out.println(title);
    }
}
