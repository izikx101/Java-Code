import java.util.Scanner;
import java.util.Random;
public class Person
{
    // instance variables - replace the example below with your own
    private String name;
    private String password;
    private int idNum;
    private int cash;
    Scanner scanner = new Scanner(System.in);
    Random r = new Random();
    
    public Person()
    {
        // initialise instance variables
        System.out.println("Enter Name");
        String name = scanner.next();
        System.out.println("Hello " + name + idNum);
        // password 8 characs
        System.out.println("Enter Password");
        String password = scanner.next();
        if(password.length()==8)
        {
            System.out.println("Welcome!");
        }
        else
        {
            System.out.println("sorry, password too long or short");
        }
        // random 0-99 for ID #
        int idNum = r.nextInt(100) + 1;
    }
}
