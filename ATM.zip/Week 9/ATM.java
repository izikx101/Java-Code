import java.util.Scanner;
public class ATM
{
    // instance variables - replace the example below with your own
    public static void main(String args[])
    {
        int cash = 10000, withdraw, deposit;
        int refill = 10000;
        Scanner sc = new Scanner(System.in);
        Person String = new Person();
        while(true)
        {
            System.out.println("Choose 1 for Withdraw");
            System.out.println("Choose 2 for Deposit");
            System.out.println("Choose 3 for Refill");
            System.out.println("Choose 4 for EXIT");
            
            int choice = sc.nextInt();
            switch(choice)
            {
                case 1:
                System.out.print("Enter money to be withdrawn:");
                withdraw = sc.nextInt();
                
                if(cash >= withdraw)
                {
                    cash = cash - withdraw;
                    System.out.println("Please collect your money");
                }
                else
                {
                    System.out.println("Insufficient cash");
                }
                System.out.println("");
                break;
                
                case 2:
                System.out.print("Enter money to be deposited:");
                deposit = sc.nextInt();
                cash = cash + deposit;
                System.out.println("Your money has been successfully deposited");
                System.out.println("");
                break;
                
                case 3:
                System.out.println("Refilled:" + refill);
                System.out.println("");
                break;
                
                case 4:
                System.exit(0);
            }
        }
    }
}